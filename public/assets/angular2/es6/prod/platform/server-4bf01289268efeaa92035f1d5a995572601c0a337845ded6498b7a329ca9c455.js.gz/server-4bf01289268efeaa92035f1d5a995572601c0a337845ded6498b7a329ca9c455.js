// TODO: vsavkin add SERVER_PROVIDERS and SERVER_APP_PROVIDERS
export { Parse5DomAdapter } from 'angular2/src/platform/server/parse5_adapter';
