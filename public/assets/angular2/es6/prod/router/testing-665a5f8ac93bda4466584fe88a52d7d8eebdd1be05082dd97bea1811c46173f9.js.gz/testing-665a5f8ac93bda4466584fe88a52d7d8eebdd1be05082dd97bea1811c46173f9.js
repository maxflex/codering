export * from 'angular2/src/mock/mock_location_strategy';
export * from 'angular2/src/mock/location_mock';
