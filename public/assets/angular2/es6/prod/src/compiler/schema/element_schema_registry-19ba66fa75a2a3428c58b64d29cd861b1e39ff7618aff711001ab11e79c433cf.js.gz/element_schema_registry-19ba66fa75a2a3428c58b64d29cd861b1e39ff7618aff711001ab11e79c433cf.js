export class ElementSchemaRegistry {
    hasProperty(tagName, propName) { return true; }
    getMappedPropName(propName) { return propName; }
}
