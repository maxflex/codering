export function isObservable(value) {
    return false;
}
