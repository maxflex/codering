export class SelectedPipe {
    constructor(pipe, pure) {
        this.pipe = pipe;
        this.pure = pure;
    }
}
