export { enableProdMode } from 'angular2/src/facade/lang';
