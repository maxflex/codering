// Public API for util
export { Class } from './util/decorators';
