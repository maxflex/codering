// Index to be used if Http is ever configured as a standalone npm package.
// require('reflect-metadata');
// require('es6-shim');
// import {HTTP_PROVIDERS, JSONP_PROVIDERS, Http, Jsonp} from './http';
// import {Injector} from 'angular2/core';
// export * from './http';
// /**
//  * TODO(jeffbcross): export each as their own top-level file, to require as:
//  * require('angular2/http'); require('http/jsonp');
//  */
// export var http = Injector.resolveAndCreate([HTTP_PROVIDERS]).get(Http);
// export var jsonp = Injector.resolveAndCreate([JSONP_PROVIDERS]).get(Jsonp);
