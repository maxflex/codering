export function bind(fn, scope) {
    return fn.bind(scope);
}
