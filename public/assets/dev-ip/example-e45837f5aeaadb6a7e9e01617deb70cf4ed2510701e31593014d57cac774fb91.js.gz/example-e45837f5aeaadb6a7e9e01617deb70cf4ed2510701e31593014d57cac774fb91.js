var devip = require("./lib/dev-ip");

var ip = devip();
console.log(ip);
