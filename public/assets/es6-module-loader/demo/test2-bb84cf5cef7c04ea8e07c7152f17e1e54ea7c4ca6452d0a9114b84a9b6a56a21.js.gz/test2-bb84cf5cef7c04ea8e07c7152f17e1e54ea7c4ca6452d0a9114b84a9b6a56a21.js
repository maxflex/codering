export class Foo {
  constructor() {
    console.log('Created the ES6 class foo!');
  }
}
