
(function (__global){
  'use strict';

  if (!__global){
    return;
  }

  document.write('<script type="module"> window.anon = class { constructor() {  } } </script>');

}(typeof window != 'undefined' && window ));


