define(['./amd-dep.js'], function(dep) {
  return {
    format: dep.name
  };
});
