define([], function() {
  return {
    name: 'amd'
  };
});
