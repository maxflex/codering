define([], function() {
  return { n: 'n' };
});
