export var bar = 'baa';
