export var bar = 'bar';
