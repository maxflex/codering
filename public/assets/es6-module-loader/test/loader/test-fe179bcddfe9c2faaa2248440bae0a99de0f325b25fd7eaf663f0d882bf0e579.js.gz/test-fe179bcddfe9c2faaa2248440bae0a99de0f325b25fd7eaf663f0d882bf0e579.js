export var loader = 'custom';
