export { g } from './_g.js';
export var f = 'f';
