export function make() {
  return new Error('Hello')
}

