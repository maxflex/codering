export function* generator() {
  yield 1;
}
