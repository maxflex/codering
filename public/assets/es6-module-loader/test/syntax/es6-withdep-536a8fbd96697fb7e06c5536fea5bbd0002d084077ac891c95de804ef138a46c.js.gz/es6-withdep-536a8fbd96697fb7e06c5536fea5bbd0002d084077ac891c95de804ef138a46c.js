export { p } from './es6-dep.js';
console.log('withdep');
