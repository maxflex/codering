export var foo = 'foo';
