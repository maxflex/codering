export var s = 4;

export default function q() {

}
