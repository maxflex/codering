"use strict";

module.exports = require("eazy-logger").Logger({
    prefix: "{blue:[}{magenta:Foxy}{blue:]} ",
    logLevel: "debug"
});
