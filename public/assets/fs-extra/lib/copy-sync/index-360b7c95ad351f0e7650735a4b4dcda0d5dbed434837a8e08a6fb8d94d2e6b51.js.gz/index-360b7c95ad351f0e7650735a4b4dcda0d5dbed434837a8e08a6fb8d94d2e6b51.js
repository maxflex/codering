module.exports = {
  copySync: require('./copy-sync')
}
