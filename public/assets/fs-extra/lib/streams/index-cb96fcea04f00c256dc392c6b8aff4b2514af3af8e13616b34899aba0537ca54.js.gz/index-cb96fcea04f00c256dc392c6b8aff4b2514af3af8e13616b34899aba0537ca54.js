module.exports = {
  createOutputStream: require('./create-output-stream')
}
