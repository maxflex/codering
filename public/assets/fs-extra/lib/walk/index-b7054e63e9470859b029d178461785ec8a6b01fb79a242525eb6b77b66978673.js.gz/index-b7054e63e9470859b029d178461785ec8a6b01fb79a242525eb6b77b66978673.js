var klaw = require('klaw')

module.exports = {
  walk: klaw
}
