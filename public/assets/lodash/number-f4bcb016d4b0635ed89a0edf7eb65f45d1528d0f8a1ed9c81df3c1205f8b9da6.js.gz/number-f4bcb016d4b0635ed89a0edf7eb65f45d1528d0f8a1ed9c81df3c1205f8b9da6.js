module.exports = {
  'random': require('./number/random')
};
