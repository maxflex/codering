(function() {
  window.odometerOptions = {
    test: 1
  };

}).call(this);
